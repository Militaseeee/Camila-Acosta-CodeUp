package com.CAV_RIWI_codeUp.academic_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcademicSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
